#!/usr/bin/env python
"""An advanced Mapper, using Python iterators and generators."""

import sys, random



def read_input(input):
    for line in input:
        if line:
            clean = re.sub('[^a-z0-9]+\s*', ' ', line.lower())
            yield clean.split()


def main(separator='\t'):
    
    k = int(sys.argv[1])
    S, c = [], 0
    for x in sys.stdin:
        if c < k: 
            S.append(x)
        else:
            r = random.randint(0,c-1)
            if r<k: S[r] = x 
        c += 1

    print(''.join(S))


if __name__ == "__main__":
    main()

