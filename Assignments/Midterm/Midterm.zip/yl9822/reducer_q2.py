#!/usr/bin/env python
"""An advanced Reducer, using Python iterators and generators."""

from itertools import groupby
from operator import itemgetter
import sys, random



def main(separator='\t'):
    # input comes from STDIN (standard input)
    k = int(sys.argv[1])
    S, c = [], 0
    for x in sys.stdin:
        if c < k: 
            S.append(x)
        else:
            r = random.randint(0,c-1)
            if r<k: S[r] = x 
        c += 1

    print(''.join(S))



if __name__ == "__main__":
    main()
