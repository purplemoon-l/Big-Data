#!/usr/bin/env python
"""An advanced Mapper, using Python iterators and generators."""

import sys



def read_input(input):
    for line in input:
        if line:
            clean = re.sub('[^a-z0-9]+\s*', ' ', line.lower())
            yield clean.split()


def main(separator='\t'):
    data = read_input(sys.stdin)

    for words in data:
        for word in words:
            print('%s%s%d' % (words, separator, 1))


if __name__ == "__main__":
    main()

