#!/usr/bin/env python
"""An advanced Mapper, using Python iterators and generators."""

import sys
import re


def read_input(input):
    for line in input:
        if line:
            remove_start = re.sub('^\S*','',line.lower())
            clean = re.sub('[^<>a-z0-9]+\s*',' ',remove_start)
            clean_tags = re.sub('<.*?>','',clean)
            clean_punctuation = re.sub('[^a-z0-9]+\s*',' ',clean_tags)
            yield clean_punctuation.split()


def main(separator='\t'):
    data = read_input(sys.stdin)
    
    for words in data:
        for word_one,word_two in zip(words[0:-1],words[1:]):
            print('%s%s%d'%(word_one+","+word_two, separator, 1))
    

if __name__ == "__main__":
    main()

