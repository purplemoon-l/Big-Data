#!/usr/bin/env python
"""An advanced Mapper, using Python iterators and generators."""

import sys
import re


def read_input(input):
    for line in input:
        if line:
            #print(line)
            clean = re.sub('[^a-z0-9]+\s*',' ',line.lower())
            yield clean.split()


def main(separator='\t'):
    data = read_input(sys.stdin)
    
    for words in data:
        for word_one,word_two in zip(words[:-1],words[1:]):
            print('%s%s%d' % (word_one+","+word_two, separator, 1))


if __name__ == "__main__":
    main()

